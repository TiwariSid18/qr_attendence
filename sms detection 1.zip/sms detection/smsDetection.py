import streamlit as st
import pickle
import string
from nltk.corpus import stopwords
import nltk
import re
from nltk.stem.porter import PorterStemmer
import spacy
from spacy.matcher import Matcher



from sklearn.feature_extraction.text import TfidfVectorizer
ps = PorterStemmer()


nlp = spacy.load("en_core_web_sm")
nlp2 = spacy.load("due_date_ner_model")



# Define pattern to match amounts denoted with "Rs."
amount_pattern = [{"LOWER": {"IN": ["rs", "inr", "₹", "rupees"]}}, {"IS_PUNCT": True, "OP": "?"}, {"LIKE_NUM": True}] #, {"LIKE_NUM": True}





# Function to detect amounts (symbol $)
def detect_amounts(text):
    doc = nlp(text)
    amounts = []
    for ent in doc.ents:
        if ent.label_ == "MONEY":
            amounts.append(ent.text)
        
    return amounts



STOPWORDS = set(stopwords.words('english'))

def clean_text(text):
    # convert to lowercase
    text = text.lower()
    text = re.sub(r'[^0-9a-zA-Z]', ' ', text)
    text = re.sub(r'\s+', ' ', text)
    # remove stopwords
    text = " ".join(word for word in text.split() if word not in STOPWORDS)
    return text


tfidf = pickle.load(open('vectorizer3.pkl','rb'))
model = pickle.load(open('model3.pkl','rb'))

st.title("Email/SMS Reminder Classifier")

input_sms = st.text_area("Enter the message")

if st.button('Predict'):

    
    transformed_sms = clean_text(input_sms)
    
    vector_input = tfidf.transform([transformed_sms])
    
    vector_input = vector_input.toarray()
    result = model.predict(vector_input)[0]
    
    if result == 1:
        st.header("Reminder")
        
   
        doc = nlp2(input_sms)

        # Extract due dates based on specific patterns in the text
        due_dates = []
        for ent in doc.ents:
            if ent.label_ == "DUE_DATE":
                # Check if at least three preceding tokens are indicative of a due date
                if ent.start >= 3:
                    preceding_tokens = [doc[i].lower_ for i in range(ent.start - 3, ent.start)]
                    if any(token in preceding_tokens for token in ["due date", "by", "before", "due on", "latest"]):
                        due_dates.append(ent.text)

        if due_dates:
            st.write("Extracted Due Dates:")
            for date in due_dates:
                st.write("- " + date)
        else:
            st.write("No due dates found in the input text.")
        
        amounts = detect_amounts(input_sms)
    
        #Extract Rs.
        doc = nlp(input_sms)
        matcher = Matcher(nlp.vocab)
        matcher.add("Amount", [amount_pattern])
        matches = matcher(doc)
        amounts_rs = []
        for match_id, start, end in matches:
          amounts_rs.append(doc[start:end].text)
    
        if amounts_rs or amounts:
            st.write("Extracted Amounts:")
        else:
           st.write("No amounts found")
        for amount in amounts_rs:
            st.write(amount)
            
        for amount in amounts:
            st.write(amount)
            
        
        
    else:
        st.header("Non-Reminder")
        
    
        
        